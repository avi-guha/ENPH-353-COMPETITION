# 353-Clueboard-Detection > 2025-11-27 5:54pm
https://universe.roboflow.com/enph252ros/353-clueboard-detection-5ualb

Provided by a Roboflow user
License: CC BY 4.0

