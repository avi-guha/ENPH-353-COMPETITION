# BabePed > 2025-12-01 5:00pm
https://universe.roboflow.com/enph252ros/babeped-jo67m

Provided by a Roboflow user
License: CC BY 4.0

